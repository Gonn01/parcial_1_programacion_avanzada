package excepciones;

public class HechizoYaAprendidoException extends Exception {
    public HechizoYaAprendidoException(String mensaje) {
        super(mensaje);
    }
}
