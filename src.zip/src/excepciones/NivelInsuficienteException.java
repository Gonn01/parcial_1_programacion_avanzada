package excepciones;

public class NivelInsuficienteException extends Exception {
    public NivelInsuficienteException(String mensaje) {
        super(mensaje);
    }
}
